package mk.ukim.finki.wp.lab.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@NoArgsConstructor
@Entity
@Getter
@Data
public class Song {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ManyToOne
    private Album album;
    private Long id;
    String trackId;
    String title;
    String genre;
    int releaseYear;
    @ManyToMany
    List<Artist> performers;

    public Song(String trackId, String title, String genre, int releaseYear) {
        this.id = (long) (Math.random() * 1000);
        this.trackId = trackId;
        this.title = title;
        this.genre = genre;
        this.releaseYear = releaseYear;

        performers = new ArrayList<>();
    }
    public void addPerformer(Artist performer) {
        performers.add(performer);
    }
    public List<Artist> getPerformers() {
        return performers;
    }

    public String getTitle() {
        return title;
    }

    public String getGenre() {
        return genre;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public String getTrackId() {
        return trackId;
    }
}

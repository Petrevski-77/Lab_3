package mk.ukim.finki.wp.lab.bootstrap;


import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Album;
import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataHolder {
    public static List<Artist> artists = new ArrayList<>();
    public static List<Song> songs = new ArrayList<>();
    public static List<Album> albums = null;

    @PostConstruct
    public void init(){
        artists.add(new Artist("Slave", "Dimitrov", "Bio od Slave Dimitrov"));
        artists.add(new Artist("Robbie", "Williams", "Bio od Robbie Williams"));
        artists.add(new Artist("Kaliopi", "Bukle", "Bio od Kaliopi Bukle"));
        artists.add(new Artist("Celine", "Dion", "Bio od Celine Dion"));
        artists.add(new Artist("Katy", "Perry", "Bio od Katy Perry"));
        songs.add(new Song("1", "Dali da ti prijdam", "male", 1974));
        songs.add(new Song("2", "Angels", "male", 1998));
        songs.add(new Song("3", "Crno i belo", "female", 2007));
        songs.add(new Song("4", "My heart will go on", "female", 1997));
        songs.add(new Song("5", "Basketball", "female", 2019));
        albums.add(new Album("album 1", "rock", "2014"));
        albums.add(new Album( "album 2", "pop", "2004"));
        albums.add(new Album("album 3", "jazz", "2010"));
        albums.add(new Album("album 4", "metal", "1980"));
        albums.add(new Album("album 5", "rock", "2002"));


    }
}
